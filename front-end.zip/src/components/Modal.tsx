

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    children: React.ReactNode;
}


import styles from './Modal.module.css';

export default function Modal({isOpen, onClose, children}: ModalProps) {
    if (!isOpen) return null;


    return (
        <>
            {/*css안에 있는 backdrop 클래스를 표현, 모달창 외부 화면은 어둡게 표시 해주기위함*/}
            <div className={styles.backdrop} onClick={closeHandler}/>
            {/*css안에 있는 modal 클래스 내용을 표현 해주기 위함.*/}
            {/*모달에 표시할 부분을 어디에 표시할지 모르기때문에 직접 props로 설정해줌 설명) PostList 안에있는 모달의 자식 컴포넌트를
            dialog를 표시 하라는 의미, PostList 안에 있는 Modal 컴포넌트에는 다른거 안해줘도 알아서 적용됨*/}
            <dialog open={true} className={styles.modal}>{props.children}
            </dialog>
        </>
    )
}


// New Post의 모달의 경우
// 1. 처음 시작할때는 모달창이 열려 있는상태(isPosting이 true인 상태) -> 지금은 기본을 false로 바꿔놓았음
// 2. 아무곳이나(div영역) 클릭하면 onClick의 props.onClose가 실행됨
// 3. 그러면 Modal의 onClose가 실행되며 props.onStopPosting이 실행됨.
// 4. 결과적으로 PostsList의 onStopPosting의 함수 hideModalHandler가 실행됨
// 5. state가 modalIsVisible를 false로 바뀌며 isPosting을 false로 변경
// 6. isPosting이 false기 때문에 Modal이 null을 실행
// 7. New Post 버튼을 누르면 onCreatePost가 실행됨
// 8. MainHeader의 onCreatePost의 함수 showModalHanler가 실행되며 modalIsVisible을 true로 변경
// 9. isPosting도 true로 변경되고 Modal이 True기 때문에 실행됨