import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
// react-route-dom 을 설치후 import
import {RouterProvider,createBrowserRouter} from 'react-router-dom'

import './index.css'

import Home from "./pages/Home.tsx";
import Login from "./User/Login.tsx";
import Signup from "./User/Signup.tsx";
import RootLayout from "./routes/RootLayout.tsx";


const router=createBrowserRouter([
    {
        path:'/',
        element:<RootLayout/>,
        children:[
            {
                path: '/',
                element: <Home/>,
                children: [
                    {path: '/login',element:<Login/>},
                    {path:'/signup',element:<Signup/>},
                ],//<our-domain>>
            },
        ],
    },
]);

createRoot(document.getElementById('root')!).render(
    <StrictMode>
        {/*route를 사용하기 위해 router를 설정해줌 기존에 있던 App컴포넌트는 router 내부로 이동*/}
        <RouterProvider router={router}/>
    </StrictMode>,
)
